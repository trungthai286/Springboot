package BtvnSpringboot.buoi9.database;

import BtvnSpringboot.buoi9.model.Product;

import java.util.ArrayList;
import java.util.List;

public class ProductDB {
    public static List<Product> products = new ArrayList<>();
}
