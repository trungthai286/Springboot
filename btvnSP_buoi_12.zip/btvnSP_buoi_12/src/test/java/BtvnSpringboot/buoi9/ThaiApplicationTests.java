package BtvnSpringboot.buoi9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
